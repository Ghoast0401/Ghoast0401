package com.Tabetomo.shop;

import java.io.Serializable;

import jakarta.validation.constraints.NotBlank;

public class ShopForm implements Serializable {

    @NotBlank(message="店舗名を入力してください")
    private String name;

    @NotBlank(message="エリアを入力してください")
    private String area;

    @NotBlank(message="住所を入力してください")
    private String address;

    @NotBlank(message="ジャンルを選択してください")
    private String genre;


    @NotBlank(message="GoogleマップURLを入力してください")
    private String mapEmbedUrl;

    public String getMapEmbedUrl() {
        return mapEmbedUrl;
    }

    public void setMapEmbedUrl(String mapEmbedUrl) {
        this.mapEmbedUrl = mapEmbedUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

}