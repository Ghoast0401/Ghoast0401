
package com.Tabetomo.shop;

import java.util.List;

import org.jspecify.annotations.Nullable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

@Service
public class ShopService {


	@Autowired
    private ShopRepository shopRepository;



 
    public com.Tabetomo.shop.ShopEntity save(ShopForm form) {
        ShopEntity shop = new ShopEntity();
        shop.setName(form.getName());
        shop.setArea(form.getArea());
        shop.setAddress(form.getAddress());
        shop.setGenre(form.getGenre());
        shop.setMapEmbedUrl(extractMapEmbedUrl(form.getMapEmbedUrl()));
        return shopRepository.save(shop);
        // status, createdAtは@PrePersistで自動設定される
    }

    // Googleマップの「地図を埋め込む」から <iframe ... src="URL" ...> を
    // そのまま貼り付けられた場合に、src の中身のURLだけを取り出す。
    // すでにURLだけが貼られている場合はそのまま返す。
    public static String extractMapEmbedUrl(String input) {
        if (input == null) {
            return null;
        }
        String trimmed = input.trim();

        java.util.regex.Matcher matcher =
                java.util.regex.Pattern.compile("src=[\"']([^\"']+)[\"']").matcher(trimmed);

        if (matcher.find()) {
            return matcher.group(1);
        }

        return trimmed;
    }
    public List<ShopEntity> findAll() {
        return shopRepository.findAll();
    }

  
 // 予測変換用：キーワードが含まれる店舗名を最大5件返す
    public List<ShopEntity> suggestShops(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return List.of();
        }
        return shopRepository.findByNameContainingIgnoreCase(keyword);
    }
	public void update(Long id, ShopEntity shopForm) {
		// TODO 自動生成されたメソッド・スタブ
		
	}
	public @Nullable Object findById(Long id) {
	
		return null;

	}

	private static final int PAGE_SIZE = 12;

	public Page<ShopEntity> search(
	        String keyword,
	        String genre,
	        String genreGroup,
	        String area,
	        String sort,
	        int page) {


		List<ShopEntity> shops =
		        shopRepository.findByStatusAndDeletedFalse("APPROVED");

	    if (keyword != null && !keyword.isBlank()) {
	        shops = shops.stream()
	                .filter(s -> s.getName().contains(keyword))
	                .toList();
	    }


	    if (genre != null && !genre.isBlank()) {
	        shops = shops.stream()
	                .filter(s -> genre.equals(s.getGenre()))
	                .toList();
	    }


	    if (area != null && !area.isBlank()) {
	        shops = shops.stream()
	                .filter(s -> area.equals(s.getArea()))
	                .toList();
	    }


	    if ("rating".equals(sort)) {

	        shops = shops.stream()
	                .sorted((a,b) ->
	                    Double.compare(
	                        b.getAverageRating(),
	                        a.getAverageRating()
	                    ))
	                .toList();

	    } else {

	        shops = shops.stream()
	                .sorted((a,b) ->
	                    b.getCreatedAt()
	                    .compareTo(a.getCreatedAt()))
	                .toList();
	    }


	    return toPage(shops,page);
	}


	private Page<ShopEntity> toPage(List<ShopEntity> shops, int page) {

	    int safePage = Math.max(page, 0);

	    int total = shops.size();

	    int start = Math.min(safePage * PAGE_SIZE, total);

	    int end = Math.min(start + PAGE_SIZE, total);


	    List<ShopEntity> content =
	            shops.subList(start, end);


	    org.springframework.data.domain.Pageable pageable =
	            org.springframework.data.domain.PageRequest
	            .of(safePage, PAGE_SIZE);


	    return new org.springframework.data.domain.PageImpl<>(
	            content,
	            pageable,
	            total
	    );
	}
}