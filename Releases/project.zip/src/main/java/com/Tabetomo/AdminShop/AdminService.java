package com.Tabetomo.AdminShop;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Tabetomo.shop.ShopEntity;
import com.Tabetomo.shop.ShopRepository;
@Service
public class AdminService {
	@Autowired
	private ShopRepository shopRepository;
	public void update(Long id, ShopEntity shopForm) {
	    ShopEntity shop = shopRepository.findById(id).orElseThrow();

	    shop.setName(shopForm.getName());
	    shop.setGenre(shopForm.getGenre());
	    shop.setArea(shopForm.getArea());
	    shop.setAddress(shopForm.getAddress());
	    shop.setMapEmbedUrl(
	            com.Tabetomo.shop.ShopService.extractMapEmbedUrl(shopForm.getMapEmbedUrl()));
	    if (shopForm.getStatus() != null && !shopForm.getStatus().isBlank()) {
	        shop.setStatus(shopForm.getStatus());
	    }

	    shopRepository.save(shop);
	}
	public void deleteShop(Long id) {

	    ShopEntity shop = shopRepository.findById(id)
	            .orElseThrow(() -> new RuntimeException("店舗が見つかりません"));

	    shop.setDeleted(true);
	    shop.setDeletedAt(LocalDateTime.now());

	    shopRepository.save(shop);
	}
	public void restoreShop(Long id) {

	    ShopEntity shop = shopRepository.findById(id)
	            .orElseThrow(() -> new RuntimeException("店舗が見つかりません"));

	    shop.setDeleted(false);
	    shop.setDeletedAt(null);

	    shopRepository.save(shop);
	}
	public void deletePermanent(Long id) {

	    shopRepository.deleteById(id);
	}
	 }