package com.Tabetomo.AdminShop;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.Tabetomo.Account.AccountEntity;
import com.Tabetomo.Account.AccountRepository;
import com.Tabetomo.shop.GenreGroup;
import com.Tabetomo.shop.ShopForm;
import com.Tabetomo.shop.ShopRepository;
@Controller
public class AdminController {

	@Autowired
	AccountRepository accountRepository;
	@Autowired
	AdminService adminService;

	@Autowired
	ShopRepository shopRepository;
	@GetMapping("/admin/shops/new")
	public String form(Model model) {
		model.addAttribute("shopForm", new ShopForm());
		model.addAttribute("genreGroups", GenreGroup.values());
		return "shop_form";

	}
	@PostMapping("/admin/shops/{id}/delete")
	public String delete(
	        @PathVariable Long id,
	        Principal principal) {

	    AccountEntity account =
	            accountRepository.findByUserName(principal.getName())
	            .orElseThrow();

	    adminService.deleteShop(id);

	    return "redirect:/admin";
	}
	@GetMapping("/admin/trash")
	public String trash(Model model) {

	    model.addAttribute("trashedShopList",
	            shopRepository.findByDeletedTrue());

	    return "admin_dashboard";
	}@PostMapping("/admin/shops/{id}/restore")
	public String restore(@PathVariable Long id) {

	    adminService.restoreShop(id);

	    return "redirect:/admin";
	}@PostMapping("/admin/shops/{id}/delete-permanently")
	public String deletePermanent(@PathVariable Long id) {

	    adminService.deletePermanent(id);

	    return "redirect:/admin";
	}
}
