package com.Tabetomo.Detail;

import java.util.ArrayList;
import java.util.List;

public class DetailDto {

	// 店舗情報
	private Long id;
	private String name;
	private String area;
	private String address;
	private String genre;
	private String mapEmbedUrl;

	// レビュー一覧
	private List<ReviewDto> reviews = new ArrayList<>();

	public DetailDto() {
	}

	public String getName() {
		return name;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getMapEmbedUrl() {
		return mapEmbedUrl;
	}

	public void setMapEmbedUrl(String mapEmbedUrl) {
		this.mapEmbedUrl = mapEmbedUrl;
	}

	public List<ReviewDto> getReviews() {
		return reviews;
	}

	public void setReviews(List<ReviewDto> reviews) {
		this.reviews = reviews;
	}
}
