package com.Tabetomo.Detail;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Tabetomo.Review.ReviewEntity;
import com.Tabetomo.Review.ReviewRepository;
import com.Tabetomo.shop.ShopEntity;
import com.Tabetomo.shop.ShopRepository;

@Service
public class DetailService {

    @Autowired
    private ShopRepository shopRepository;

    @Autowired
    private ReviewRepository reviewRepository;

    public DetailDto getDetail(Long userId) {

        System.out.println("id = " + userId);

        ShopEntity shop = shopRepository.findById(userId).orElse(null);

        System.out.println("shop = " + shop);

        if (shop == null) {
            return null;
        }

        // レビュー取得
        List<ReviewEntity> reviewList = reviewRepository.findByShop_Id(userId);

        List<ReviewDto> dtoList = new ArrayList<>();

        for (ReviewEntity review : reviewList) {

            ReviewDto dto = new ReviewDto();

            dto.setUserId(review.getUserId());
            dto.setId(review.getId());
            // ←ReviewEntityに合わせて変更
            dto.setRating(review.getRating());
            dto.setComment(review.getComment());
            dto.setCreatedAt(review.getCreatedAt());

            dtoList.add(dto);
        }

        // 店舗情報
        DetailDto detailDto = new DetailDto();

        detailDto.setId(shop.getId());
        
        detailDto.setName(shop.getName());
        detailDto.setArea(shop.getArea());
        detailDto.setGenre(shop.getGenre());
        detailDto.setAddress(shop.getAddress());
        detailDto.setMapEmbedUrl(shop.getMapEmbedUrl());

        // レビュー一覧
        detailDto.setReviews(dtoList);

        return detailDto;
    }

}