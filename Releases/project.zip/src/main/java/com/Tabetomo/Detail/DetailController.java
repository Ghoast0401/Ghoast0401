package com.Tabetomo.Detail;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.Tabetomo.Account.AccountEntity;
import com.Tabetomo.Review.ReviewEntity;

import jakarta.servlet.http.HttpSession;


@Controller
@RequestMapping("/shop")
public class DetailController {

    @Autowired
    private DetailService detailService;

    @GetMapping("/detail/{id}")
    public String detail(@PathVariable("id") Long id, Model model,
    		 HttpSession session ) {
    	AccountEntity account = (AccountEntity) session.getAttribute("account");
    	ReviewEntity review = (ReviewEntity) session.getAttribute("review");
    	model.addAttribute("account", account);
    	model.addAttribute("review", review);
        DetailDto dto = detailService.getDetail(id);
        if (dto == null) {
            model.addAttribute("errorMessage", "指定された店舗が見つかりませんでした。");
            return "error/not_found"; // 専用のエラーページ(要作成)
        }
        model.addAttribute("detail", dto);
        return "shop_detail";
    }
}