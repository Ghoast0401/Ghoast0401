package com.Tabetomo.Review;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.Tabetomo.Detail.DetailDto;
import com.Tabetomo.Detail.DetailService;
import com.Tabetomo.shop.ShopRepository;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/review")
public class ReviewController {

	@Autowired
	private ReviewService reviewService;
	@Autowired
	private ShopRepository shopRepository;
	@Autowired
	private DetailService detailService;

	//投稿フォーム画面表示
	// ① 投稿フォーム画面表示
	@GetMapping("/form/{id}")
	public String review(@PathVariable("id") Long id, Model model) {

		DetailDto detailDto = detailService.getDetail(id);

		ReviewForm reviewForm = new ReviewForm();
		reviewForm.setShopId(id);

		model.addAttribute("detailDto", detailDto);
		model.addAttribute("reviewForm", new ReviewForm());
		return "review_form";
	}

	@PostMapping("/confirm")
	public String confirm(@Valid @ModelAttribute ReviewForm reviewForm,
			BindingResult result,
			HttpSession session,
			Model model) {

		if (result.hasErrors()) {
			return "review_form";
		}

		DetailDto detailDto = detailService.getDetail(reviewForm.getShopId());

		model.addAttribute("detailDto", detailDto);
		model.addAttribute("reviewForm", reviewForm);

		session.setAttribute("reviewForm", reviewForm);

		return "review_confirm";
	}

	// ②→① [戻る] ボタン押下時(入力内容を保持したままフォームへ)
	@PostMapping("/back")
	public String back(HttpSession session, Model model) {

		ReviewForm form = (ReviewForm) session.getAttribute("reviewForm");

		DetailDto detailDto = detailService.getDetail(form.getShopId());

		model.addAttribute("detailDto", detailDto);
		model.addAttribute("reviewForm", form);

		return "review_form";
	}

	@PostMapping("/submit")
	public String submit(@Valid @ModelAttribute ReviewForm reviewForm,
			BindingResult result,
			Model model,
			Principal principal) { // ★追加
		System.out.println("★★★★★ submit() が呼ばれました ★★★★★");
		if (result.hasErrors()) {
			result.getFieldErrors()
					.forEach(error -> System.out.println(error.getField() + " : " + error.getDefaultMessage()));
			return "review_submit_success";
		}
		System.out.println("保存開始");
		reviewService.save(reviewForm, principal.getName()); // ★ログインIDを渡す
		System.out.println("保存終了");
		model.addAttribute("message", "店舗の登録が完了しました。");
		return "review_submit_success";
	}
}