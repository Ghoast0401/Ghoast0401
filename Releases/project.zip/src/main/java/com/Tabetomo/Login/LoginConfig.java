package com.Tabetomo.Login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class LoginConfig {

	@Autowired
	private LoginService customUserDetailsService;

	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

		http
				.userDetailsService(customUserDetailsService)

				.authorizeHttpRequests(auth -> auth
						.requestMatchers(
							      "/", 
							           // トップページ（店舗一覧）
							        "/login",                   // ログイン画面
							        "/register",              // アカウント作成画面
							        "/register/**",
							        "/main/**",               // アカウント作成処理
							        "/css/**",
							        "/js/**",
							        "/images/**",
							        "/Guest", "/Guest/**",
							        "/shop/detail/**",
							        "/review/form/**",
							        "/shop/search",       // ★追加 (完全一致)
							        "/shop/search/**",
							        "/mypage/**",
							        "/api/shops/suggest", // ★追加 (予測変換用API)
							        "/error",              // ★追加 (隠れエラー回避用)
							        "/favicon.ico"
						).permitAll()

			    .requestMatchers("/admin/**","/admin").hasRole("ADMIN")

			    .anyRequest().authenticated()
			)
				.formLogin(form -> form
					    .loginPage("/login")
					    .successHandler((request, response, authentication) -> {

					        boolean admin = authentication.getAuthorities().stream()
					                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

					        if (admin) {
					            response.sendRedirect("/admin");
					        } else {
					            response.sendRedirect("/");
					        }
					    })
					    .permitAll()
					    )
					    .logout(logout -> logout
					    	    .logoutUrl("/logout")
					    	    .logoutSuccessUrl("/") // ログアウト後にメイン画面へ
					    	    .invalidateHttpSession(true)
					    	    .deleteCookies("JSESSIONID")
					    	    .permitAll()
	);
		return http.build();
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return PasswordEncoderFactories.createDelegatingPasswordEncoder();
	}
}