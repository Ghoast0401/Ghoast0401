package tabetomo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(
	    scanBasePackages = { "tabetomo", "com.Tabetomo", }
	)
	@EnableJpaRepositories(basePackages = { "com.Tabetomo" })
	@EntityScan(basePackages = "com.Tabetomo")
	public class ReleaseApplication {
    public static void main(String[] args) {
        SpringApplication.run(ReleaseApplication.class, args);
    }
}